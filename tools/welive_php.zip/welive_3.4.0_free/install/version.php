<?php
	$WeLiveVersion = '3.4.0';
?>