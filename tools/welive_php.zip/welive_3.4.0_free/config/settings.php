<?php

$_CFG = array();

$_CFG['cActived'] = "1";
$_CFG['cUpdate'] = "6";
$_CFG['cAutoOffline'] = "10";
$_CFG['cLang'] = "Auto";
$_CFG['cTimezone'] = "+8";
$_CFG['cDateFormat'] = "Y-m-d";
$_CFG['cTitle'] = "WeLive在线客服系统";
$_CFG['cTitle_en'] = "WeLive Online Support";
$_CFG['cWelcome'] = "欢迎您登录客服系统, 请咨询, 谢谢!";
$_CFG['cWelcome_en'] = "Welcome! please post your question...";
$_CFG['cAppVersion'] = '3.4.0';
$_CFG['cAppName'] = "V2VMaXZl";
$_CFG['cAppCopyrighURL'] = "aHR0cDovL3d3dy53ZWVudGVjaC5jb20v";
$_CFG['cKillRobotCode'] = '6ae772acb8cbad6e48de9d15927d8d17';
$_CFG['cDeleteHistory'] = "12";
$_CFG['cBannedips'] = "";
$_CFG['cBadwords'] = "";
$_CFG['cPanalHeight'] = "200";

?>